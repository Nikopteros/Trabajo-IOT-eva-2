#include "WiFiS3.h"   // Librería WiFi del Arduino UNO R4 WiFi (ya viene incluida)

// ====== 1. CAMBIA ESTO ANTES DE SUBIR EL CODIGO A LA PLACA ======
// (No subas tus datos reales a un repositorio público)
const char ssid[] = "RiegoIoT";
const char pass[] = "Babuino123";

// Token simple para proteger las rutas de control.
// Solo letras y números (sin & ? = # % + ni espacios).
// Debe ser IDENTICO al que use la app Android.
const char apiKey[] = "tokensecreto";
// ================================================================

const int soilPin = A0;
const int pumpPin = 9;

// Tipo de planta
// 1 = Bajo consumo de agua
// 2 = Consumo medio
// 3 = Alto consumo de agua
int plantType = 2;

// Umbrales (valor alto = suelo seco)
int onThreshold;
int offThreshold;

bool pumpOn = false;

// Modos de funcionamiento
//  MODO_OFF  : sistema apagado, no lee el sensor y la bomba no se enciende
//  MODO_AUTO : riega solo según el sensor
//  MODO_ON   : debug, la bomba riega siempre sin mirar el sensor
enum Modo { MODO_OFF, MODO_AUTO, MODO_ON };
Modo modo = MODO_AUTO;

int soilValue = 0;
unsigned long lastRead = 0;      // para medir el tiempo sin usar delay()
unsigned long lastIpPrint = 0;   // para repetir la IP cada cierto tiempo

WiFiServer server(80);           // servidor web en el puerto 80

void setup() {
  pinMode(pumpPin, OUTPUT);
  digitalWrite(pumpPin, LOW);

  Serial.begin(9600);

  // Configurar los umbrales según el tipo de planta
  aplicarTipoPlanta(plantType);

  // (Opcional) IP fija: descomenta y ajusta a la subred de tu router.
  // WiFi.config(IPAddress(192, 168, 1, 50));

  // Conectarse al WiFi
  Serial.print("Conectando a ");
  Serial.println(ssid);

  int status = WL_IDLE_STATUS;
  while (status != WL_CONNECTED) {
    status = WiFi.begin(ssid, pass);
    Serial.println("Intentando conectar...");
    delay(5000);
  }

  // Esperar a que el router entregue una IP válida (máx. 15 segundos)
  int intentos = 0;
  while (WiFi.localIP()[0] == 0 && intentos < 30) {
    delay(500);
    intentos++;
  }

  server.begin();

  Serial.println("¡Conectado!");
  Serial.print("Abre esta direccion en tu navegador: http://");
  Serial.println(WiFi.localIP());
}

void loop() {
  atenderClienteWeb();   // revisa si alguien hizo una petición (app o navegador)

  // Cada 10 segundos, repetir la IP por el Serial Monitor
  if (millis() - lastIpPrint >= 10000) {
    lastIpPrint = millis();
    Serial.print("IP actual: ");
    Serial.println(WiFi.localIP());
  }

  // Cada 1 segundo, controlar el riego (reemplaza al delay(1000) de antes)
  if (millis() - lastRead >= 1000) {
    lastRead = millis();
    controlarRiego();
  }
}

// Fija los umbrales según el tipo de planta.
// Se llama al iniciar y cada vez que la app cambia el tipo.
void aplicarTipoPlanta(int tipo) {
  plantType = tipo;
  switch (plantType) {
    case 1:
      onThreshold = 750;
      offThreshold = 500;
      break;
    case 2:
      onThreshold = 700;
      offThreshold = 500;
      break;
    case 3:
      onThreshold = 650;
      offThreshold = 450;
      break;
  }
  pumpOn = false;   // reiniciar el estado de la bomba al cambiar de margen
}

void controlarRiego() {
  // MODO APAGADO: ni siquiera se lee el sensor
  if (modo == MODO_OFF) {
    pumpOn = false;
    digitalWrite(pumpPin, LOW);
    Serial.println("SISTEMA: DESACTIVADO (sin lectura)");
    return;
  }

  soilValue = analogRead(soilPin);

  Serial.print("Humedad: ");
  Serial.println(soilValue);

  // MODO DEBUG / SIEMPRE ENCENDIDO: ignora el sensor
  if (modo == MODO_ON) {
    pumpOn = true;
    digitalWrite(pumpPin, HIGH);
    Serial.println("MODO DEBUG: BOMBA SIEMPRE ENCENDIDA");
    return;
  }

  // MODO AUTOMATICO
  // Suelo seco -> comenzar riego
  if (soilValue > onThreshold) {
    pumpOn = true;
  }

  // Suelo suficientemente húmedo -> detener riego
  if (soilValue < offThreshold) {
    pumpOn = false;
  }

  if (pumpOn) {
    digitalWrite(pumpPin, HIGH);
    Serial.println("BOMBA: ENCENDIDA");
  } else {
    digitalWrite(pumpPin, LOW);
    Serial.println("BOMBA: APAGADA");
  }
}

void atenderClienteWeb() {
  WiFiClient client = server.available();
  if (!client) return;

  String request = "";
  String currentLine = "";
  unsigned long start = millis();

  while (client.connected() && millis() - start < 2000) {
    if (client.available()) {
      char c = client.read();
      request += c;

      if (c == '\n') {
        if (currentLine.length() == 0) {
          // Fin de la petición: ya podemos responder.
          // Solo importa la primera línea, ej: "GET /mode?v=off&key=XXXX HTTP/1.1"
          int fin = request.indexOf('\n');
          String linea = request.substring(0, fin);

          procesarPeticion(client, linea);
          break;
        }
        currentLine = "";
      } else if (c != '\r') {
        currentLine += c;
      }
    }
  }
  client.stop();
}

// Página de monitoreo (solo lectura, no tiene botones de control)
void enviarPagina(WiFiClient &client) {
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: text/html; charset=utf-8");
  client.println("Connection: close");
  client.println();

  client.println("<!DOCTYPE html><html><head>");
  client.println("<meta charset='utf-8'>");
  client.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
  client.println("<meta http-equiv='refresh' content='3'>");   // se actualiza cada 3 s
  client.println("<title>Riego automático</title>");
  client.println("<style>");
  client.println("body{font-family:Arial;text-align:center;margin-top:40px;}");
  client.println("</style></head><body>");

  client.println("<h1>Riego automático</h1>");

  client.print("<p>Humedad (sensor): <b>");
  client.print(soilValue);
  client.println("</b></p>");

  client.print("<p>Modo: <b>");
  client.print(nombreModo());
  client.println("</b></p>");

  client.print("<p>Tipo de planta: <b>");
  client.print(plantType);
  client.println("</b></p>");

  client.print("<p>Bomba: <b>");
  client.print(pumpOn ? "ENCENDIDA" : "APAGADA");
  client.println("</b></p>");

  client.println("</body></html>");
}

void procesarPeticion(WiFiClient &client, const String &linea) {
  // Página de monitoreo (solo lectura, sin botones)
  if (linea.startsWith("GET / ")) {
    enviarPagina(client);
    return;
  }

  // Todo lo demás exige el token. La clave debe ir como ULTIMO parámetro.
  String claveEsperada = "key=" + String(apiKey) + " ";
  if (linea.indexOf(claveEsperada) < 0) {
    responderError(client, 403, "Forbidden");
    return;
  }

  // Estado en JSON: /status?key=...
  if (linea.startsWith("GET /status")) {
    responderJSON(client);
    return;
  }

  // Cambio de modo: /mode?v=off|auto|always&key=...
  if (linea.startsWith("GET /mode?v=")) {
    if      (linea.indexOf("v=off&")    >= 0) modo = MODO_OFF;
    else if (linea.indexOf("v=auto&")   >= 0) modo = MODO_AUTO;
    else if (linea.indexOf("v=always&") >= 0) modo = MODO_ON;
    else { responderError(client, 400, "Bad Request"); return; }

    pumpOn = false;     // que AUTO decida desde cero
    controlarRiego();   // aplicar el cambio de inmediato
    responderJSON(client);
    return;
  }

  // Cambio de planta: /plant?v=1|2|3&key=...
  if (linea.startsWith("GET /plant?v=")) {
    if      (linea.indexOf("v=1&") >= 0) aplicarTipoPlanta(1);
    else if (linea.indexOf("v=2&") >= 0) aplicarTipoPlanta(2);
    else if (linea.indexOf("v=3&") >= 0) aplicarTipoPlanta(3);
    else { responderError(client, 400, "Bad Request"); return; }

    controlarRiego();   // aplicar el cambio de inmediato
    responderJSON(client);
    return;
  }

  responderError(client, 404, "Not Found");
}

const char* nombreModo() {
  switch (modo) {
    case MODO_OFF: return "off";
    case MODO_ON:  return "always";
    default:       return "auto";
  }
}

void responderJSON(WiFiClient &client) {
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: application/json");
  client.println("Connection: close");
  client.println();
  client.print("{\"humidity\":"); client.print(soilValue);
  client.print(",\"pump\":");     client.print(pumpOn ? "true" : "false");
  client.print(",\"mode\":\"");   client.print(nombreModo());
  client.print("\",\"plant\":");  client.print(plantType);
  client.print(",\"on\":");       client.print(onThreshold);
  client.print(",\"off\":");      client.print(offThreshold);
  client.println("}");
}

void responderError(WiFiClient &client, int codigo, const char* texto) {
  client.print("HTTP/1.1 ");
  client.print(codigo);
  client.print(" ");
  client.println(texto);
  client.println("Connection: close");
  client.println();
}
