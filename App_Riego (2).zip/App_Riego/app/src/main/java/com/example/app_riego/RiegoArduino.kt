package com.example.app_riego

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Error con un mensaje listo para mostrarle al usuario
class ErrorRiego(mensaje: String) : Exception(mensaje)

class RiegoArduino(private val ip: String, private val token: String) : RiegoRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    // key= va siempre al final, como exige el Arduino
    override suspend fun obtenerEstado() = pedir("status?key=$token")
    override suspend fun cambiarModo(modo: String) = pedir("mode?v=$modo&key=$token")
    override suspend fun cambiarPlanta(tipo: Int) = pedir("plant?v=$tipo&key=$token")

    private suspend fun pedir(ruta: String): EstadoRiego = withContext(Dispatchers.IO) {
        val peticion = try {
            Request.Builder().url("http://$ip/$ruta").build()
        } catch (e: IllegalArgumentException) {
            throw ErrorRiego("La IP configurada no es válida")
        }

        client.newCall(peticion).execute().use { respuesta ->
            when (respuesta.code) {
                200 -> Unit
                403 -> throw ErrorRiego("Token incorrecto")
                else -> throw ErrorRiego("El Arduino respondió con error ${respuesta.code}")
            }

            val json = JSONObject(respuesta.body.string())
            EstadoRiego(
                humedad = json.getInt("humidity"),
                bomba = json.getBoolean("pump"),
                modo = json.getString("mode"),
                planta = json.getInt("plant"),
                umbralOn = json.getInt("on"),
                umbralOff = json.getInt("off")
            )
        }
    }
}
