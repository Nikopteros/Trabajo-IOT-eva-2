package com.example.app_riego

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class RiegoViewModel(app: Application) : AndroidViewModel(app) {

    private val ajustes = AjustesStore(app)
    private var repo: RiegoRepository = crearRepositorio()

    private val _estado = MutableStateFlow<EstadoRiego?>(null)
    val estado: StateFlow<EstadoRiego?> = _estado

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private var job: Job? = null

    // Datos actuales, para mostrarlos en la ventana de ajustes
    val ip: String get() = ajustes.ip
    val token: String get() = ajustes.token
    val usandoSimulador: Boolean get() = ajustes.usarSimulador

    private fun crearRepositorio(): RiegoRepository =
        if (ajustes.usarSimulador) RiegoSimulado()
        else RiegoArduino(ajustes.ip, ajustes.token)

    // Consulta el estado cada 2 segundos
    fun iniciarActualizacion() {
        if (job?.isActive == true) return
        job = viewModelScope.launch {
            while (true) {
                ejecutar { repo.obtenerEstado() }
                delay(2000)
            }
        }
    }

    fun detenerActualizacion() {
        job?.cancel()
    }

    // Guarda la nueva configuración y reinicia la conexión
    fun aplicarAjustes(ip: String, token: String, simulador: Boolean) {
        ajustes.ip = ip
        ajustes.token = token
        ajustes.usarSimulador = simulador

        val estabaActivo = job?.isActive == true
        job?.cancel()
        repo = crearRepositorio()
        _estado.value = null
        _error.value = null
        if (estabaActivo) iniciarActualizacion()
    }

    fun cambiarModo(modo: String) {
        viewModelScope.launch { ejecutar { repo.cambiarModo(modo) } }
    }

    fun cambiarPlanta(tipo: Int) {
        viewModelScope.launch { ejecutar { repo.cambiarPlanta(tipo) } }
    }

    // Ejecuta una acción y guarda el resultado, o el error si falla
    private suspend fun ejecutar(accion: suspend () -> EstadoRiego) {
        try {
            _estado.value = accion()
            _error.value = null
        } catch (e: CancellationException) {
            throw e   // cancelar la consulta no es un error de conexión
        } catch (e: ErrorRiego) {
            _error.value = e.message
        } catch (e: Exception) {
            _error.value = "Sin conexión con el riego"
        }
    }
}
