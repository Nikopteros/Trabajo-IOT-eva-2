package com.example.app_riego

import kotlinx.coroutines.delay

class RiegoSimulado : RiegoRepository {
    private var humedad = 600
    private var bomba = false
    private var modo = "auto"
    private var planta = 2
    private var umbralOn = 700
    private var umbralOff = 500

    private fun umbrales(tipo: Int): Pair <Int, Int> = when (tipo) {
        1 -> 750 to 500
        3 -> 650 to 450
        else -> 700 to 500
    }

    //imita lo que hace controlarRiego() del arduino
    private fun avanzar() {
        if (modo == "off") {
            bomba = false //apagado: no lee ni riega
            return
        }
        if (modo == "always") {
            bomba = true
        } else {
            if (humedad > umbralOn) bomba = true
            if (humedad < umbralOff) bomba = false
        }
        // Valor alto = suelo seco. con la bomba prendida baja, apagada sube.
        humedad += if (bomba) -25 else 15
        humedad = humedad.coerceIn(300, 900)
    }

    private fun estado() = EstadoRiego(humedad, bomba, modo, planta, umbralOn, umbralOff)
    override suspend fun obtenerEstado(): EstadoRiego {
        delay(200) //imita la demora de la red
        avanzar()
        return estado()
    }

    override suspend fun cambiarModo(modo: String): EstadoRiego {
        delay(200)
        this.modo = modo
        bomba = false // igual que en el arduino: auto decide desde cero
        avanzar()
        return estado()
    }

    override suspend fun cambiarPlanta(tipo: Int): EstadoRiego {
        delay(200)
        planta = tipo
        val (on, off) = umbrales(tipo)
        umbralOn = on
        umbralOff = off
        bomba = false
        avanzar()
        return estado()
    }

}