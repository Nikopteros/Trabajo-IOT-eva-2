package com.example.app_riego

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.app_riego.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import android.content.Intent
import com.google.firebase.auth.FirebaseAuth
import androidx.appcompat.app.AlertDialog
import com.example.app_riego.databinding.DialogAjustesBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: RiegoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Sin sesión no se puede ver el panel
        val usuario = FirebaseAuth.getInstance().currentUser
        if (usuario == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        configurarBotones()
        observarEstado()
        binding.tvUsuario.text = "Sesión: ${usuario.email}"
        binding.btnAjustes.setOnClickListener { mostrarAjustes() }
        binding.btnCerrarSesion.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(
                Intent(this, LoginActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.iniciarActualizacion()
    }

    override fun onStop() {
        super.onStop()
        viewModel.detenerActualizacion()
    }

    private fun configurarBotones() {
        binding.groupPlanta.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val tipo = when (checkedId) {
                R.id.btnPlanta1 -> 1
                R.id.btnPlanta3 -> 3
                else -> 2
            }
            if (viewModel.estado.value?.planta != tipo) {
                viewModel.cambiarPlanta(tipo)
            }
        }

        binding.groupModo.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val modo = when (checkedId) {
                R.id.btnModoOff -> "off"
                R.id.btnModoSiempre -> "always"
                else -> "auto"
            }
            if (viewModel.estado.value?.modo != modo) {
                viewModel.cambiarModo(modo)
            }
        }
    }

    private fun observarEstado() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.estado.collect { estado ->
                        if (estado != null) mostrar(estado)
                    }
                }
                launch {
                    viewModel.error.collect { error ->
                        binding.tvConexion.text = error ?: textoConexion()
                    }
                }
            }
        }
    }
    private fun textoConexion(): String =
        if (viewModel.usandoSimulador) "Conectado (simulador)" else "Conectado al Arduino"

    private fun mostrarAjustes() {
        val dialogo = DialogAjustesBinding.inflate(layoutInflater)
        dialogo.etIp.setText(viewModel.ip)
        dialogo.etToken.setText(viewModel.token)
        dialogo.swSimulador.isChecked = viewModel.usandoSimulador

        val alerta = MaterialAlertDialogBuilder(this)
            .setTitle("Conexión con el Arduino")
            .setView(dialogo.root)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)   // se maneja abajo para validar sin cerrar
            .create()

        alerta.setOnShowListener {
            alerta.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val ip = dialogo.etIp.text.toString().trim()
                val token = dialogo.etToken.text.toString().trim()
                val simulador = dialogo.swSimulador.isChecked
                dialogo.tilIp.error = null
                dialogo.tilToken.error = null

                if (!simulador) {
                    if (!Regex("""^(\d{1,3}\.){3}\d{1,3}$""").matches(ip)) {
                        dialogo.tilIp.error = "IP no válida (ej: 192.168.1.50)"
                        return@setOnClickListener
                    }
                    if (!Regex("[A-Za-z0-9]+").matches(token)) {
                        dialogo.tilToken.error = "Solo letras y números"
                        return@setOnClickListener
                    }
                }
                viewModel.aplicarAjustes(ip, token, simulador)
                alerta.dismiss()
            }
        }
        alerta.show()
    }

    private fun mostrar(e: EstadoRiego) {
        if (viewModel.error.value == null) binding.tvConexion.text = textoConexion()
        // Apagado: el Arduino no lee el sensor, así que no hay valor que mostrar
        binding.tvHumedad.text = if (e.modo == "off") "Sin lectura" else e.humedad.toString()
        binding.tvBomba.text = if (e.bomba) "Bomba: ENCENDIDA" else "Bomba: APAGADA"

        binding.tvModo.text = when (e.modo) {
            "off" -> "Modo: Apagado"
            "always" -> "Modo: Siempre encendido (debug)"
            else -> "Modo: Automático"
        }
        binding.tvUmbrales.text = "Enciende sobre ${e.umbralOn} · Apaga bajo ${e.umbralOff}"

        binding.groupPlanta.check(
            when (e.planta) {
                1 -> R.id.btnPlanta1
                3 -> R.id.btnPlanta3
                else -> R.id.btnPlanta2
            }
        )
        binding.groupModo.check(
            when (e.modo) {
                "off" -> R.id.btnModoOff
                "always" -> R.id.btnModoSiempre
                else -> R.id.btnModoAuto
            }
        )
    }
}