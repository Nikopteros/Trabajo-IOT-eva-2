package com.example.app_riego

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.app_riego.databinding.ActivityLoginBinding
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import android.util.Log
import com.google.firebase.auth.FirebaseAuthException

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Si ya hay una sesión abierta, saltar directo al panel
        if (auth.currentUser != null) {
            irAlPanel()
            return
        }

        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.login) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        binding.btnIngresar.setOnClickListener { enviar(registrar = false) }
        binding.btnRegistrar.setOnClickListener { enviar(registrar = true) }
    }

    private fun enviar(registrar: Boolean) {
        val correo = binding.etCorreo.text.toString().trim()
        val clave = binding.etClave.text.toString()

        // Validar antes de molestar a Firebase
        if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            binding.tvMensaje.text = "Escribe un correo válido"
            return
        }
        if (clave.length < 6) {
            binding.tvMensaje.text = "La contraseña debe tener al menos 6 caracteres"
            return
        }

        binding.tvMensaje.text = ""
        activarBotones(false)

            val tarea = if (registrar) {
            auth.createUserWithEmailAndPassword(correo, clave)
        } else {
            auth.signInWithEmailAndPassword(correo, clave)
        }

        tarea.addOnCompleteListener(this) { resultado ->
            if (resultado.isSuccessful) {
                irAlPanel()
            } else {
                activarBotones(true)
                Log.e("Login", "Falló la autenticación", resultado.exception)
                binding.tvMensaje.text = when (val error = resultado.exception) {
                    is FirebaseAuthInvalidUserException,
                    is FirebaseAuthInvalidCredentialsException -> "Correo o contraseña incorrectos"
                    is FirebaseAuthUserCollisionException -> "Ese correo ya está registrado"
                    is FirebaseNetworkException -> "Sin conexión a internet"
                    is FirebaseAuthException -> "No se pudo completar (${error.errorCode})"
                    else -> "No se pudo completar: ${error?.message}"
                }
            }
        }
    }

    private fun activarBotones(activos: Boolean) {
        binding.btnIngresar.isEnabled = activos
        binding.btnRegistrar.isEnabled = activos
    }

    private fun irAlPanel() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
