package com.example.app_riego

import android.content.Context

class AjustesStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("ajustes_riego", Context.MODE_PRIVATE)

    var ip: String
        get() = prefs.getString("ip", "") ?: ""
        set(valor) = prefs.edit().putString("ip", valor).apply()

    var token: String
        get() = prefs.getString("token", "") ?: ""
        set(valor) = prefs.edit().putString("token", valor).apply()

    // Por defecto usa el simulador, así la app funciona antes de configurar nada
    var usarSimulador: Boolean
        get() = prefs.getBoolean("simulador", true)
        set(valor) = prefs.edit().putBoolean("simulador", valor).apply()
}
