package com.example.app_riego
data class EstadoRiego(
    val humedad: Int,
    val bomba: Boolean, //"off" "auto" y "always"
    val modo: String,   //1, 2 o 3
    val planta: Int,
    val umbralOn: Int,
    val umbralOff: Int

)
