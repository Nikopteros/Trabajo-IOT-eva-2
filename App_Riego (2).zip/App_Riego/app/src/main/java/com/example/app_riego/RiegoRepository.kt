package com.example.app_riego
interface RiegoRepository {
    suspend fun obtenerEstado(): EstadoRiego
    suspend fun cambiarModo(modo: String): EstadoRiego
    suspend fun cambiarPlanta(tipo: Int): EstadoRiego
}
